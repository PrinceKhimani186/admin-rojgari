</div>


        <footer class="footer">
            <div class="container-fluid">
                <p class="copyright" style="text-align: center;">
                    &copy; 2018 All right reserved. <a target="_blank" href="http://foursis.com">Foursis.com</a>
                </p>
            </div>
        </footer>

    </div>
</div>


</body>

	<!--   Core JS Files   -->
	
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="../assets/plugin/select2/update_js/select2.min.js" type="text/javascript"></script>
	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>
	<!--  Notifications Plugin    -->
	<script src="assets/js/bootstrap-notify.js"></script>
    <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
	<script src="assets/js/light-bootstrap-dashboard.js?v=1.4.0"></script>
	<script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
	<script src="assets/js/custom.js"></script>
	
</html>