<section class="allcontainer">
    <div class="container">
       <div class="row">
		<div class="threecolumn">
                <div class="leftbar"><?php include('sidebar.php'); ?></div>
                <div class="middlebar">
			<div class="rightbarinner">
                            <h2 class="pagetitleinner">Dashboard</h2>
                            
                            <div class="instruction">
                                <ul>
                                    <li>Edit your profile preferences so we can search best job for you.</li>
                                    <li>If you are not paid member. Or you are not having any Membership then you can get only 5 jobs details.</li>
                                    <li>So be carefull to open contact detail of job. Because after that you will not be able to open any contact detail of job until you make the payment.</li>
                                </ul>
                            </div>
                        </div>
                </div>
                </div>
       </div>
    </div>
</section>
